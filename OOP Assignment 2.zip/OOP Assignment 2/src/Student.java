public class Student extends Person implements Comparable<Person>, Payable{
    private double gpa;

    public Student() {
        super();
    }

    public Student(String name, String surname, double gpa) {
        super(name, surname);
        this.gpa = gpa;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        return "Student: " + super.toString();
    }
    public double getPaymentAmount() {
        return (getGpa() > 2.67) ? 36660.00 : 0.0;
    }
    public int compareTo(Person otherPerson) {
        if (otherPerson instanceof Student) {
            Student otherStudent = (Student) otherPerson;
            return Double.compare(this.getPaymentAmount(), otherStudent.getPaymentAmount());
        }
        return super.compareTo(otherPerson);
    }
}