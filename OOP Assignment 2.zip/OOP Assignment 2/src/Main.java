import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        Employee employee1 = new Employee("John", "Lennon", "Manager", 27045.78);
        Employee employee2 = new Employee("George", "Harrison", "Developer", 50000.00);
        Student student1 = new Student("Ringo", "Starr", 2.5);
        Student student2 = new Student("Paul", "McCartney", 3.0);

        List<Person> personList = new ArrayList<>();
        personList.add(employee1);
        personList.add(employee2);
        personList.add(student1);
        personList.add(student2);

        Collections.sort(personList);

        printData(personList);
    }

    public static void printData(Iterable<Person> people) {
        for (Person person : people) {
            if (person instanceof Payable) {
                Payable payablePerson = (Payable) person;
                System.out.println(person.toString() + " earns " + payablePerson.getPaymentAmount() + " tenge");
            } else {
                System.out.println(person.toString() + " does not have a payment amount");
            }
        }
    }
}
