public interface Payable {
    double getPaymentAmount();
}